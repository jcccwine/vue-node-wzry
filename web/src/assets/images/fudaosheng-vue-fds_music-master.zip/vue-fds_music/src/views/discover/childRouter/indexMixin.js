export const imgLoad={
    methods:{
        imgLoad() {
            /**父组件是beter-scroll */
            this.$refs.scroll.refresh();
          },
    }
}