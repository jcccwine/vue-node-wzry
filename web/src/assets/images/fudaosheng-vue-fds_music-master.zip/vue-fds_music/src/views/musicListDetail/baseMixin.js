export const baseMixin={
    methods:{
        allPlay(){
          this.$emit("allPlay");
        }
      }
}